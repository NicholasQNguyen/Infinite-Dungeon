
import pygame

from .mobile import Mobile
from .drawable import Drawable
from .vector2D import Vector2
import os

   

class Grass(Drawable):
   """Grass does not move but can change its image."""
   def __init__(self, position):
      super().__init__("flowers-color-key.png", position, (114,116), pygame.Rect(456,116,114,116))
      self._grassImage = self._image
      
      image = pygame.image.load(os.path.join("images", self._imageName)).convert()
         
      self._roseImage = pygame.Surface((114,116))
      self._roseImage.blit(image, (0,0), pygame.Rect(342,232,114,116))
      
      self._roseImage.set_colorkey(self._image.get_at((0,0)))
   
   def changeToRose(self):
      self.setImage(self._roseImage)
      
   def changeToGrass(self):
      self.setImage(self._grassImage)
      
   

   
   
   
      