This work was released by Bonsaiheldin under the Creative Commons BY 4.0 license.

For further information, please check: https://creativecommons.org/licenses/by/4.0/

How to credit me (for example): Bonsaiheldin (http://bonsaiheld.org)

----------

Although it's not really necessary, it does make me happy to know what you do with my work.
It took me time to create it, so why not drop me a line somewhere if you happen to use it? :)
