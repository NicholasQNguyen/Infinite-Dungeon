import pygame
from pygame import image
import os
from .vector2D import Vector2

class Drawable(object):
   """Anything that can be drawn in the game inherits from this class."""
   
   
   def __init__(self, imageName, position, size, subImageRect=None):
      self._imageName = imageName


      self._image = pygame.image.load(os.path.join("images", self._imageName)).convert()
         
      if subImageRect:
         surf = pygame.Surface(size)
         surf.blit(self._image, (0,0), subImageRect)
         self._image = surf
      
      self._image.set_colorkey(self._image.get_at((0,0)))

      self._position = Vector2(*position)
      
   def getPosition(self):
      return self._position

   def setPosition(self, newPosition):
      self._position = newPosition
      
   def getSize(self):
      return self._image.get_size()
   
   def setImage(self, surface):
      self._image = surface

   def getCollisionRect(self):
      newRect =  self._position + self._image.get_rect()
      return newRect
   
   def draw(self, surface):
      surface.blit(self._image, (self._position[0], self._position[1]))
     